package com.tools;


public class FileManager {

	// get the file's suffix.
	public static String getSuffix(String fileName) {
		if (fileName.length() < 5) {
			return "";
		} else {
			String result = fileName.substring(fileName.lastIndexOf(".") + 1,
					fileName.length());
			return result;
		}
	}

	// get the file's name (exclude suffix)
	public static String getFileNameWithoutSuffix(String fileName) {
		if (fileName.length() < 5) {
			return "";
		} else {
			String result = fileName.substring(0, fileName.lastIndexOf("."));
			return result;
		}
	}

	

	public static void main(String args[]) {
		//resolvePath("D:/Git_1.1/ArtResource/art/IngameResource/ANI/BallAnimation/heihei");
		// testList();
		// testMap();
	}

	public static boolean isXXXFile(String path, String XXX)
	{
		path = path.toLowerCase();
		if(path.indexOf(XXX,path.length()-4) != -1)
			return true;
		else
			return false;
	}

	public static void trace(String str) {
		System.out.println(str);
	}
}
