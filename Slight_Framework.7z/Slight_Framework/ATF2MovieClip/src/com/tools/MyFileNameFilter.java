package com.tools;

import java.io.File;
import java.io.FilenameFilter;

//A Filename Filter
public class MyFileNameFilter implements FilenameFilter {
	private String type;

	public MyFileNameFilter(String filtersType) {
		this.type = filtersType;
	}

	@Override
	public boolean accept(File dir, String path) {
		String[] filters = type.split(",");
		for (String filterType : filters) {
			if (path.indexOf(filterType) != -1)
				return true;
			else
			{
				File file = new File(dir+"\\"+path);
				if(file.isDirectory())
					return true;
			}
		}
		return false;
	}
}
