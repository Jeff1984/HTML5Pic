package com.tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;

//We can detect whether the xml is utf8 or utf16 in windows, but it does not
//work in Mac, fortunately, XML is saved as only UTF8 data format in Mac.

public class MyReadFile {
	public static String readFileAsString(String path) throws IOException {
		FileInputStream stream = new FileInputStream(new File(path));
		String result = "";
		try {
			FileChannel fc = stream.getChannel();
			MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0,
					fc.size());
				if (isUTF8(path)) {
					result = Charset.defaultCharset().decode(bb).toString();
				} else {
					Charset charset = Charset.forName("UTF-16");
					result = charset.decode(bb).toString();
				}
		} finally {
			stream.close();
		}
		return result;
	}
	
		/**
		 * @param path  file's path
		 *  If file name is a number, so it's a Sprite Table XML which is stored as utf-16 in
		 *  windows.
		 *  Otherwise, the file will be a MovieClip XML stored as a utf8-without-bom data format
		 *  so it can't be detected by the first 3 byte. normally, it named 'main.xml'
		 */
		private static boolean isUTF8(String path) {
			File file = new File(path);
			boolean result = true;
			if(file.isFile())
			{
				String fileName = FileManager.getFileNameWithoutSuffix(file.getName());
				try
				{
					Integer.parseInt(fileName);
					result = false;
				}catch(NumberFormatException e)
				{
				}
			}
			return result;
		}
	
	//Get xml's content
		public static byte[] readXMLAsUTF8(String path){
			try {
				String str = MyReadFile.readFileAsString(path);
				byte[] utf8 = str.getBytes("UTF-8");
				return utf8;
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		//Get byte array of file
		public static byte[] readATFAsBytes(String path) {
			try {
				RandomAccessFile file = new RandomAccessFile(path, "r");
				byte[] result = new byte[(int) file.length()];
				file.read(result);
				return result;
			} catch (Exception e) {
				return null;
			}
		}
}
