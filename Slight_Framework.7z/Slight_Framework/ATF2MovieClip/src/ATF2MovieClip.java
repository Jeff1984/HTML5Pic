import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import com.tools.FileManager;
import com.tools.MyFileNameFilter;
import com.tools.MyReadFile;

public class ATF2MovieClip {
	// static File _file;
	// static FileInputStream _fileInputStream;
	// static FileChannel _fileChannel;
	// static int _size;
	static RandomAccessFile _readFile;
	static File _outFile;
	static FileInputStream _fs;
	
	public static void main(String args[]) {
	//	resolvePath("D:\\Git_1.1\\ArtResource\\art\\IngameResource\\ANI","ani");
		if(args.length == 0)
		{
			System.out.println("java -jar ATF2MovieClip.jar [sourcePath] [ani/vsa]");
		}else if(args.length == 2)
			resolvePath(args[0],args[1]);
	}
	
	// Resolve the file.
		// There are three kinds file in a folder: ATF, TextureAtlas XML, MovieClip
		// XML root element -> File Type
		// TextureAtlas -> TextureAtlas XML
		// animations -> ani movieclip
		// displayobjects -> vff movieclip
		/**
		 * @param path				resource's path
		 * @param movieClipType		vff or ani
		 * @return
		 */
		public static void resolvePath(String path,String movieClipType) {
			File file = new File(path);
			List<String> list = new ArrayList<String>();
			if (file.isDirectory()) {
				MyFileNameFilter ff = new MyFileNameFilter("xml,atf");
				File[] files = file.listFiles(ff);
				for (File subFile : files) {
					if(subFile.isFile())
						list.add(subFile.getPath());
					else if(subFile.isDirectory())
					{
						resolvePath(subFile.getPath(), movieClipType);
					}
				}
			} 
			try {
				packageFiles(list,movieClipType);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		public static void packageFiles(List<String> list,String movieClipType) throws Exception
		{
			if(list.size() >= 3)
			{
				DataOutputStream dos;
				File temp = new File(list.get(0));
				String newFileName = temp.getParent()+"\\"+temp.getParentFile().getName()+"."+movieClipType;
				dos = new DataOutputStream(new FileOutputStream(newFileName));
				dos.writeInt(list.size());
				dos.flush();
				List<byte[]> filesBytes=new ArrayList<byte[]>();
				for(String filePath:list)
				{
					temp = new File(filePath);
					byte[] bytes;
					if(FileManager.isXXXFile(filePath,"atf"))
					{
						System.out.println("atf file to "+newFileName);
						bytes = MyReadFile.readATFAsBytes(filePath);
						dos.writeInt(bytes.length);
						dos.flush();
						filesBytes.add(bytes);
					}
					else if(FileManager.isXXXFile(filePath,"xml"))
					{
						bytes = MyReadFile.readXMLAsUTF8(filePath);
						dos.writeInt(bytes.length);
						dos.flush();
						filesBytes.add(bytes);
					}
				}
				for(byte[] by:filesBytes)
				{
					dos.write(by);
					dos.flush();
					Thread.sleep(200);
				}
				dos.close();
			}
		}
}
