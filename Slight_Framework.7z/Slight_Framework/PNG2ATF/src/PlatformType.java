


/*
 * ImgTech (iOS)	PVRTC
	Qualcom (Android)	ETC1
	Mali (Android)	ETC1
	NVidia (Android)	ETC1/DXT1/DXT5
	Android (PowerVR)	PVRTC/ETC1
	Windows	DXT1/DXT5
	MacOS	DXT1/DXT5
 * */

/**
 * @author zhaqijie
 * 2013-02-25 14:55:06
 */

public class PlatformType {
	public static String ANDROID="e";
	public static String WINDOWS_MAC="d";
	public static String IOS="p";
}
