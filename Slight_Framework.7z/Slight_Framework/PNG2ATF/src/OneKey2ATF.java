
import java.io.File;

/**
 * @author zhaqijie
 * 2013-02-25 14:55:27
 */
public class OneKey2ATF {
	/**
	 * @param pngPath		atf file's path
	 * @param platformType	d->mac&windows e->android p->ios
	 * @param emptyMip		generate empty mips. 0 is false, 1 is true
	 * @param quality		quantization level. 0 == lossless. [0,180]
	 * @param trim			trim flex bits. 0 == lossless.		[0,15]
	 * @throws Exception
	 */
	public static void convertPNG2ATF(String pngPath, String platformType,boolean emptyMip,String quality,String trim,String parameter) throws Exception
	{
		
		File file = new File(pngPath);
		if(!file.exists())
			return;
		StringBuffer sb = new StringBuffer("png2atf -c ");
		sb.append(platformType+" ");
		String atfFilePath = FileManager.getFileNameWithoutSuffix(file.getPath()) + ".atf";
		atfFilePath = "\"" + atfFilePath + "\"";
		pngPath = "\""+pngPath+"\"";
		if(emptyMip)
			sb.append("-e ");
		sb.append(parameter + " -q "+quality+" ");
		sb.append("-f "+trim+" ");
		sb.append("-i " + pngPath + " -o " + atfFilePath);
		System.out.println(sb.toString());
		Runtime.getRuntime().exec(sb.toString());
	}
	
	/**
	 * @param resourcePath	resource's path
	 */
	public static void ergodicPath(String resourcePath, String platformType, boolean emptyMip, String quality, String trim, String parameter) throws Exception
	{
		File file = new File(resourcePath);
		if(!file.exists())
			return;
		if(file.isDirectory())
		{
			File[] files = file.listFiles();
			String subPath;
			for(File subFile:files)
			{
				if(subFile.isDirectory())
					ergodicPath(subFile.getPath(),platformType,emptyMip,quality,trim, parameter);
				else
				{
					subPath = subFile.getPath();
					subPath = subPath.toLowerCase();
					if(subPath.indexOf(".png", subPath.length()-4) != -1)
					{
						convertPNG2ATF(subFile.getPath(), platformType, emptyMip, quality, trim, parameter);
					}
				}
			}
		}
	}
	
	public static void main(String args[])
	{
		try {
			//convertPNG2ATF("D:\\OldDemo\\atf2vff\\2.png",PlatformType.WINDOWS_MAC,false,50,15);
			boolean emptyMip=false;
			String platformType="d";
			String quality="0";
			String trim="0";
			String parameter = "";
			if(args.length<1)
			{
				System.out.println("java -jar OneKey2ATF.jar [pngPath] [platformType] [quality] [trim] [emptyMip] [parameter]");
				System.out.println("pngPath				atf file's path");
				System.out.println("platformType = d		d->mac&windows e->android p->ios");
				System.out.println("quality = 0			quantization level. 0 == lossless. [0,180]");
				System.out.println("trim = 0			trim flex bits. 0 == lossless.		[0,15]");
				System.out.println("emptyMip = 0			generate empty mips. 0 is false, 1 is true");
				System.out.println("parameter = ''			other parameter");
				System.out.println("When execute this command, please wait for a while until");
				System.out.println("all atf files has been generated.");
				return;
			}
			String path=args[0];
			//如果路径中有空格，则在两边加上双引号
			if(args.length > 1)
			{
				platformType = args[1];
			}
			if(args.length > 2)
			{
				quality = args[2];
			}
			if(args.length > 3)
			{
				trim = args[3];
			}
			if(args.length > 4)
			{
				if(args[4] == "1")
					emptyMip = true;
			}
			if(args.length>5)
				parameter = args[5];
			ergodicPath(path,platformType,emptyMip,quality,trim,parameter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void trace(String str) {
		System.out.println(str);
	}
}
