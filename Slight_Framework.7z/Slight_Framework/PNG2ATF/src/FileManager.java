public class FileManager {
	//get the file's name (exclude suffix)
	public static String getFileNameWithoutSuffix(String fileName)
	{
		if (fileName.length() < 5) {
			return "";
		} else {
			String result = fileName.substring(0,fileName.lastIndexOf("."));
			return result;
		}
	}
}
